

class hello_cdac {
    public static void main(String[] args) {
        System.out.println("Hello C-DAC");
        System.out.println("Hello from  C-DAC ");	
    }
}
