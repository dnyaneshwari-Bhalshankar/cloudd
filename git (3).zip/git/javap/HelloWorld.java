public class HelloWorld
{
  public static void main(String []args)
    {
        System.out.println("My First Java Program.");
  System.out.println("My First Java Program useing java.");
  System.out.println("My First Java Program useing java in CDAC.");
    }
  

}